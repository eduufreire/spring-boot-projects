package com.example.projectvalidation2103;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectValidation2103ApplicationTests {

	@Test
	void contextLoads() {
	}

}
